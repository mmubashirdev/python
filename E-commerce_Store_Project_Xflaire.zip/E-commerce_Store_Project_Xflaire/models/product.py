"""
Product CRUD operations
"""
from database.db_connection import db


class Product:
    """Handle product operations"""
    
    @staticmethod
    def create_product(product_name, category, description, price, final_price, 
                      color, available, vendor_id):
        """Create new product (CREATE operation)"""
        query = """
            INSERT INTO product 
            (product_name, category, product_description, price, final_price, 
             color, available, rate, vendor_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)
        """
        return db.execute_update(query, (product_name, category, description, 
                                        price, final_price, color, available, vendor_id))
    
    @staticmethod
    def get_all_products():
        """Get all products (READ operation)"""
        query = """
            SELECT p.serial_no, p.product_name, p.category, p.product_description,
                   p.price, p.final_price, p.color, p.available, p.rate,
                   v.vendor_name, v.company_name
            FROM product p
            JOIN vendor v ON p.vendor_id = v.vendor_id
            ORDER BY p.serial_no DESC
        """
        return db.execute_query(query)
    
    @staticmethod
    def get_products_by_vendor(vendor_id):
        """Get products by specific vendor (READ operation)"""
        query = """
            SELECT serial_no, product_name, category, product_description,
                   price, final_price, color, available, rate
            FROM product
            WHERE vendor_id = ?
            ORDER BY serial_no DESC
        """
        return db.execute_query(query, (vendor_id,))
    
    @staticmethod
    def get_available_products():
        """Get only available products for customers"""
        query = """
            SELECT p.serial_no, p.product_name, p.category, p.product_description,
                   p.price, p.final_price, p.color, p.rate,
                   v.vendor_name, v.company_name
            FROM product p
            JOIN vendor v ON p.vendor_id = v.vendor_id
            WHERE p.available = 'Yes'
            ORDER BY p.serial_no DESC
        """
        return db.execute_query(query)
    
    @staticmethod
    def get_product_by_id(serial_no):
        """Get single product by ID"""
        query = """
            SELECT serial_no, product_name, category, product_description,
                   price, final_price, color, available, rate, vendor_id
            FROM product
            WHERE serial_no = ?
        """
        result = db.execute_query(query, (serial_no,))
        return result[0] if result else None
    
    @staticmethod
    def update_product(serial_no, product_name, category, description, 
                      price, final_price, color, available):
        """Update product details (UPDATE operation)"""
        query = """
            UPDATE product
            SET product_name = ?, category = ?, product_description = ?,
                price = ?, final_price = ?, color = ?, available = ?
            WHERE serial_no = ?
        """
        return db.execute_update(query, (product_name, category, description,
                                        price, final_price, color, available, serial_no))
    
    @staticmethod
    def delete_product(serial_no):
        """Delete product (DELETE operation)"""
        query = "DELETE FROM product WHERE serial_no = ?"
        return db.execute_update(query, (serial_no,))
    
    @staticmethod
    def search_products(search_term):
        """Search products by name or category"""
        query = """
            SELECT p.serial_no, p.product_name, p.category, p.product_description,
                   p.price, p.final_price, p.color, p.rate,
                   v.vendor_name, v.company_name
            FROM product p
            JOIN vendor v ON p.vendor_id = v.vendor_id
            WHERE p.available = 'Yes' 
            AND (p.product_name LIKE ? OR p.category LIKE ?)
            ORDER BY p.serial_no DESC
        """
        search_pattern = f"%{search_term}%"
        return db.execute_query(query, (search_pattern, search_pattern))