"""
Order management operations
"""
from database.db_connection import db
from datetime import datetime


class Order:
    """Handle order operations"""
    
    @staticmethod
    def create_order(customer_id, total_amount, payment_type, cart_items):
        """Create new order with order items"""
        try:
            # Insert order
            order_query = """
                INSERT INTO orders 
                (order_date, total_amount, payment_type, order_status, customer_id)
                VALUES (?, ?, ?, 'Pending', ?)
            """
            db.execute_update(order_query, (datetime.now(), total_amount, 
                                           payment_type, customer_id))
            
            # Get the last inserted order_no
            order_no = db.execute_scalar("SELECT SCOPE_IDENTITY()")
            
            # Insert order items
            for item in cart_items:
                item_query = """
                    INSERT INTO order_items 
                    (order_no, product_serial, quantity, price_each)
                    VALUES (?, ?, ?, ?)
                """
                db.execute_update(item_query, (order_no, item['serial_no'], 
                                              item['quantity'], item['price']))
            
            return True
        except Exception as e:
            print(f"Error creating order: {e}")
            return False
    
    @staticmethod
    def get_customer_orders(customer_id):
        """Get all orders for a customer"""
        query = """
            SELECT order_no, order_date, total_amount, payment_type, order_status
            FROM orders
            WHERE customer_id = ?
            ORDER BY order_date DESC
        """
        return db.execute_query(query, (customer_id,))
    
    @staticmethod
    def get_order_items(order_no):
        """Get items in a specific order"""
        query = """
            SELECT oi.id, p.product_name, oi.quantity, oi.price_each,
                   (oi.quantity * oi.price_each) as total_price
            FROM order_items oi
            JOIN product p ON oi.product_serial = p.serial_no
            WHERE oi.order_no = ?
        """
        return db.execute_query(query, (order_no,))
    
    @staticmethod
    def get_all_orders():
        """Get all orders for admin view"""
        query = """
            SELECT o.order_no, o.order_date, o.total_amount, o.payment_type,
                   o.order_status, c.customer_name, c.first_name, c.last_name
            FROM orders o
            JOIN customer c ON o.customer_id = c.customer_id
            ORDER BY o.order_date DESC
        """
        return db.execute_query(query)
    
    @staticmethod
    def get_vendor_orders(vendor_id):
        """Get orders containing vendor's products"""
        query = """
            SELECT DISTINCT o.order_no, o.order_date, o.total_amount, 
                   o.payment_type, o.order_status, c.customer_name
            FROM orders o
            JOIN customer c ON o.customer_id = c.customer_id
            JOIN order_items oi ON o.order_no = oi.order_no
            JOIN product p ON oi.product_serial = p.serial_no
            WHERE p.vendor_id = ?
            ORDER BY o.order_date DESC
        """
        return db.execute_query(query, (vendor_id,))
    
    @staticmethod
    def update_order_status(order_no, new_status):
        """Update order status"""
        query = "UPDATE orders SET order_status = ? WHERE order_no = ?"
        return db.execute_update(query, (new_status, order_no))