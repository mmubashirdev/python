"""
User authentication and management operations
"""
from database.db_connection import db


class User:
    """Handle user authentication and operations"""
    
    @staticmethod
    def authenticate_admin(username, password):
        """Authenticate admin user"""
        query = """
            SELECT admin_id, admin_name, first_name, last_name, email 
            FROM admins 
            WHERE admin_name = ? AND password = ?
        """
        result = db.execute_query(query, (username, password))
        if result and len(result) > 0:
            return {
                'user_id': result[0][0],
                'username': result[0][1],
                'first_name': result[0][2],
                'last_name': result[0][3],
                'email': result[0][4],
                'role': 'admin'
            }
        return None
    
    @staticmethod
    def authenticate_vendor(username, password):
        """Authenticate vendor user"""
        query = """
            SELECT vendor_id, vendor_name, first_name, last_name, email, company_name 
            FROM vendor 
            WHERE vendor_name = ? AND password = ?
        """
        result = db.execute_query(query, (username, password))
        if result and len(result) > 0:
            return {
                'user_id': result[0][0],
                'username': result[0][1],
                'first_name': result[0][2],
                'last_name': result[0][3],
                'email': result[0][4],
                'company_name': result[0][5],
                'role': 'vendor'
            }
        return None
    
    @staticmethod
    def authenticate_customer(username, password):
        """Authenticate customer user"""
        query = """
            SELECT customer_id, customer_name, first_name, last_name, email 
            FROM customer 
            WHERE customer_name = ? AND password = ?
        """
        result = db.execute_query(query, (username, password))
        if result and len(result) > 0:
            return {
                'user_id': result[0][0],
                'username': result[0][1],
                'first_name': result[0][2],
                'last_name': result[0][3],
                'email': result[0][4],
                'role': 'customer'
            }
        return None
    
    @staticmethod
    def register_customer(username, password, first_name, last_name, email):
        """Register new customer"""
        query = """
            INSERT INTO customer (customer_name, password, first_name, last_name, email)
            VALUES (?, ?, ?, ?, ?)
        """
        return db.execute_update(query, (username, password, first_name, last_name, email))
    
    @staticmethod
    def get_all_customers():
        """Get all customers for admin view"""
        query = "SELECT customer_id, customer_name, first_name, last_name, email FROM customer"
        return db.execute_query(query)
    
    @staticmethod
    def get_all_vendors():
        """Get all vendors for admin view"""
        query = """
            SELECT vendor_id, vendor_name, first_name, last_name, email, company_name 
            FROM vendor
        """
        return db.execute_query(query)
    
    @staticmethod
    def get_all_delivery_persons():
        """Get all delivery persons for admin view"""
        query = """
            SELECT delivery_id, username, first_name, last_name, email 
            FROM delivery_person
        """
        return db.execute_query(query)