"""
Login and Registration Window
"""
import tkinter as tk
from tkinter import ttk, messagebox
from models.user import User
from utils.config import *


class LoginWindow:
    """Login and registration interface"""
    
    def __init__(self, root, on_login_success):
        self.root = root
        self.on_login_success = on_login_success
        self.setup_ui()
    
    def setup_ui(self):
        """Setup login window UI"""
        # Clear window
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Main frame
        main_frame = tk.Frame(self.root, bg=COLOR_LIGHT)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_frame = tk.Frame(main_frame, bg=COLOR_PRIMARY, height=80)
        title_frame.pack(fill=tk.X)
        title_frame.pack_propagate(False)
        
        tk.Label(title_frame, text="xflaire", font=("Arial", 32, "bold"),
                bg=COLOR_PRIMARY, fg="white").pack(pady=15)
        
        # Login form frame
        form_frame = tk.Frame(main_frame, bg=COLOR_LIGHT)
        form_frame.pack(expand=True)
        
        # Login section
        tk.Label(form_frame, text="Login to Your Account", 
                font=("Arial", 18, "bold"), bg=COLOR_LIGHT,
                fg=COLOR_DARK).pack(pady=20)
        
        # Username
        tk.Label(form_frame, text="Username:", font=("Arial", 12),
                bg=COLOR_LIGHT).pack(anchor=tk.W, padx=50)
        self.username_entry = tk.Entry(form_frame, font=("Arial", 12), width=30)
        self.username_entry.pack(pady=5, padx=50)
        
        # Password
        tk.Label(form_frame, text="Password:", font=("Arial", 12),
                bg=COLOR_LIGHT).pack(anchor=tk.W, padx=50, pady=(10, 0))
        self.password_entry = tk.Entry(form_frame, font=("Arial", 12), 
                                      width=30, show="*")
        self.password_entry.pack(pady=5, padx=50)
        
        # Role selection
        tk.Label(form_frame, text="Login as:", font=("Arial", 12),
                bg=COLOR_LIGHT).pack(anchor=tk.W, padx=50, pady=(10, 0))
        
        self.role_var = tk.StringVar(value="customer")
        role_frame = tk.Frame(form_frame, bg=COLOR_LIGHT)
        role_frame.pack(pady=5)
        
        tk.Radiobutton(role_frame, text="Customer", variable=self.role_var,
                      value="customer", font=("Arial", 10), bg=COLOR_LIGHT).pack(side=tk.LEFT, padx=10)
        tk.Radiobutton(role_frame, text="Vendor", variable=self.role_var,
                      value="vendor", font=("Arial", 10), bg=COLOR_LIGHT).pack(side=tk.LEFT, padx=10)
        tk.Radiobutton(role_frame, text="Admin", variable=self.role_var,
                      value="admin", font=("Arial", 10), bg=COLOR_LIGHT).pack(side=tk.LEFT, padx=10)
        
        # Login button
        tk.Button(form_frame, text="Login", font=("Arial", 12, "bold"),
                 bg=COLOR_SECONDARY, fg="white", width=25, height=2,
                 command=self.login).pack(pady=20)
        
        # Register link
        register_frame = tk.Frame(form_frame, bg=COLOR_LIGHT)
        register_frame.pack()
        
        tk.Label(register_frame, text="Don't have an account?",
                font=("Arial", 10), bg=COLOR_LIGHT).pack(side=tk.LEFT)
        tk.Button(register_frame, text="Register as Customer",
                 font=("Arial", 10, "underline"), bg=COLOR_LIGHT,
                 fg=COLOR_SECONDARY, bd=0, cursor="hand2",
                 command=self.show_register).pack(side=tk.LEFT, padx=5)
    
    def login(self):
        """Handle login"""
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        role = self.role_var.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter username and password")
            return
        
        # Authenticate based on role
        user_data = None
        if role == "admin":
            user_data = User.authenticate_admin(username, password)
        elif role == "vendor":
            user_data = User.authenticate_vendor(username, password)
        elif role == "customer":
            user_data = User.authenticate_customer(username, password)
        
        if user_data:
            messagebox.showinfo("Success", f"Welcome {user_data['first_name']}!")
            self.on_login_success(user_data)
        else:
            messagebox.showerror("Error", "Invalid username or password")
    
    def show_register(self):
        """Show registration form"""
        # Clear window
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Main frame
        main_frame = tk.Frame(self.root, bg=COLOR_LIGHT)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_frame = tk.Frame(main_frame, bg=COLOR_PRIMARY, height=80)
        title_frame.pack(fill=tk.X)
        title_frame.pack_propagate(False)
        
        tk.Label(title_frame, text="xflaire - Register", font=("Arial", 32, "bold"),
                bg=COLOR_PRIMARY, fg="white").pack(pady=15)
        
        # Registration form
        form_frame = tk.Frame(main_frame, bg=COLOR_LIGHT)
        form_frame.pack(expand=True)
        
        tk.Label(form_frame, text="Create Customer Account",
                font=("Arial", 18, "bold"), bg=COLOR_LIGHT,
                fg=COLOR_DARK).pack(pady=20)
        
        # Form fields
        fields = [
            ("Username:", "username"),
            ("Password:", "password"),
            ("First Name:", "first_name"),
            ("Last Name:", "last_name"),
            ("Email:", "email")
        ]
        
        self.register_entries = {}
        for label, key in fields:
            tk.Label(form_frame, text=label, font=("Arial", 12),
                    bg=COLOR_LIGHT).pack(anchor=tk.W, padx=50, pady=(5, 0))
            entry = tk.Entry(form_frame, font=("Arial", 12), width=30)
            if key == "password":
                entry.config(show="*")
            entry.pack(pady=5, padx=50)
            self.register_entries[key] = entry
        
        # Buttons
        button_frame = tk.Frame(form_frame, bg=COLOR_LIGHT)
        button_frame.pack(pady=20)
        
        tk.Button(button_frame, text="Register", font=("Arial", 12, "bold"),
                 bg=COLOR_SUCCESS, fg="white", width=12, height=2,
                 command=self.register).pack(side=tk.LEFT, padx=10)
        
        tk.Button(button_frame, text="Back to Login", font=("Arial", 12),
                 bg=COLOR_DARK, fg="white", width=12, height=2,
                 command=self.setup_ui).pack(side=tk.LEFT, padx=10)
    
    def register(self):
        """Handle registration"""
        username = self.register_entries['username'].get().strip()
        password = self.register_entries['password'].get().strip()
        first_name = self.register_entries['first_name'].get().strip()
        last_name = self.register_entries['last_name'].get().strip()
        email = self.register_entries['email'].get().strip()
        
        if not all([username, password, first_name, last_name, email]):
            messagebox.showerror("Error", "All fields are required")
            return
        
        if User.register_customer(username, password, first_name, last_name, email):
            messagebox.showinfo("Success", "Registration successful! Please login.")
            self.setup_ui()
        else:
            messagebox.showerror("Error", "Registration failed. Username may already exist.")