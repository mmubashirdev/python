"""
Customer/Buyer Portal Interface
"""
import tkinter as tk
from tkinter import ttk, messagebox
from models.product import Product
from models.order import Order
from utils.config import *


class CustomerPortal:
    """Customer dashboard interface"""
    
    def __init__(self, root, user_data, on_logout):
        self.root = root
        self.user_data = user_data
        self.on_logout = on_logout
        self.cart = []  # Shopping cart
        self.setup_ui()
    
    def setup_ui(self):
        """Setup customer portal UI"""
        # Clear window
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Main container
        main_frame = tk.Frame(self.root, bg=COLOR_LIGHT)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Header
        header_frame = tk.Frame(main_frame, bg=COLOR_PRIMARY, height=60)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text=f"xflaire - Shop",
                font=("Arial", 20, "bold"), bg=COLOR_PRIMARY,
                fg="white").pack(side=tk.LEFT, padx=20)
        
        tk.Label(header_frame, text=f"Welcome, {self.user_data['first_name']}",
                font=("Arial", 12), bg=COLOR_PRIMARY,
                fg="white").pack(side=tk.RIGHT, padx=10)
        
        tk.Button(header_frame, text="Logout", font=("Arial", 10),
                 bg=COLOR_DANGER, fg="white", command=self.on_logout).pack(side=tk.RIGHT, padx=10)
        
        # Content area
        content_frame = tk.Frame(main_frame, bg=COLOR_LIGHT)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Menu buttons
        menu_frame = tk.Frame(content_frame, bg=COLOR_LIGHT)
        menu_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(menu_frame, text="Browse Products", font=("Arial", 11),
                 bg=COLOR_SECONDARY, fg="white", width=15,
                 command=self.show_products).pack(side=tk.LEFT, padx=5)
        
        tk.Button(menu_frame, text=f"Cart ({len(self.cart)})", font=("Arial", 11),
                 bg=COLOR_WARNING, fg="white", width=15,
                 command=self.show_cart).pack(side=tk.LEFT, padx=5)
        
        tk.Button(menu_frame, text="My Orders", font=("Arial", 11),
                 bg=COLOR_SUCCESS, fg="white", width=15,
                 command=self.show_orders).pack(side=tk.LEFT, padx=5)
        
        # Search frame
        search_frame = tk.Frame(content_frame, bg=COLOR_LIGHT)
        search_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(search_frame, text="Search:", font=("Arial", 11),
                bg=COLOR_LIGHT).pack(side=tk.LEFT, padx=5)
        
        self.search_entry = tk.Entry(search_frame, font=("Arial", 11), width=30)
        self.search_entry.pack(side=tk.LEFT, padx=5)
        
        tk.Button(search_frame, text="Search", font=("Arial", 10),
                 bg=COLOR_SECONDARY, fg="white",
                 command=self.search_products).pack(side=tk.LEFT, padx=5)
        
        tk.Button(search_frame, text="Show All", font=("Arial", 10),
                 bg=COLOR_DARK, fg="white",
                 command=self.show_products).pack(side=tk.LEFT, padx=5)
        
        # Display area
        self.display_frame = tk.Frame(content_frame, bg="white", relief=tk.RIDGE, bd=2)
        self.display_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Show products by default
        self.show_products()
    
    def clear_display(self):
        """Clear display area"""
        for widget in self.display_frame.winfo_children():
            widget.destroy()
    
    def show_products(self):
        """Display available products"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="Available Products",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        # Create treeview
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("ID", "Name", "Category", "Price", "Color", "Rating", "Vendor")
        self.product_tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                                        yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.product_tree.yview)
        
        widths = [50, 180, 120, 100, 100, 80, 150]
        for col, width in zip(columns, widths):
            self.product_tree.heading(col, text=col)
            self.product_tree.column(col, width=width)
        
        self.product_tree.pack(fill=tk.BOTH, expand=True)
        
        # Load products
        products = Product.get_available_products()
        if products:
            for product in products:
                # Display relevant columns
                display_data = (product[0], product[1], product[2], product[5],
                              product[6], product[7], product[8])
                self.product_tree.insert("", tk.END, values=display_data)
        
        # Action buttons
        button_frame = tk.Frame(self.display_frame, bg="white")
        button_frame.pack(pady=10)
        
        tk.Button(button_frame, text="Add to Cart", font=("Arial", 11),
                 bg=COLOR_SUCCESS, fg="white", width=15,
                 command=self.add_to_cart).pack(side=tk.LEFT, padx=5)
        
        tk.Button(button_frame, text="View Details", font=("Arial", 11),
                 bg=COLOR_SECONDARY, fg="white", width=15,
                 command=self.view_product_details).pack(side=tk.LEFT, padx=5)
    
    def search_products(self):
        """Search products by name or category"""
        search_term = self.search_entry.get().strip()
        if not search_term:
            messagebox.showwarning("Warning", "Please enter a search term")
            return
        
        self.clear_display()
        
        tk.Label(self.display_frame, text=f"Search Results for: {search_term}",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("ID", "Name", "Category", "Price", "Color", "Rating", "Vendor")
        self.product_tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                                        yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.product_tree.yview)
        
        widths = [50, 180, 120, 100, 100, 80, 150]
        for col, width in zip(columns, widths):
            self.product_tree.heading(col, text=col)
            self.product_tree.column(col, width=width)
        
        self.product_tree.pack(fill=tk.BOTH, expand=True)
        
        products = Product.search_products(search_term)
        if products:
            for product in products:
                display_data = (product[0], product[1], product[2], product[5],
                              product[6], product[7], product[8])
                self.product_tree.insert("", tk.END, values=display_data)
        else:
            tk.Label(tree_frame, text="No products found",
                    font=("Arial", 12), bg="white").pack(pady=20)
        
        button_frame = tk.Frame(self.display_frame, bg="white")
        button_frame.pack(pady=10)
        
        tk.Button(button_frame, text="Add to Cart", font=("Arial", 11),
                 bg=COLOR_SUCCESS, fg="white", width=15,
                 command=self.add_to_cart).pack(side=tk.LEFT, padx=5)
    
    def add_to_cart(self):
        """Add selected product to cart"""
        selection = self.product_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a product")
            return
        
        item = self.product_tree.item(selection[0])
        product_data = item['values']
        
        # Check if already in cart
        for cart_item in self.cart:
            if cart_item['serial_no'] == product_data[0]:
                cart_item['quantity'] += 1
                messagebox.showinfo("Success", "Quantity updated in cart")
                self.update_cart_button()
                return
        
        # Add new item to cart
        self.cart.append({
            'serial_no': product_data[0],
            'name': product_data[1],
            'price': product_data[3],
            'quantity': 1
        })
        
        messagebox.showinfo("Success", f"{product_data[1]} added to cart")
        self.update_cart_button()
    
    def update_cart_button(self):
        """Update cart button text with item count"""
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Frame):
                for child in widget.winfo_children():
                    if isinstance(child, tk.Frame):
                        for button in child.winfo_children():
                            if isinstance(button, tk.Button) and "Cart" in button.cget("text"):
                                button.config(text=f"Cart ({len(self.cart)})")
    
    def view_product_details(self):
        """View detailed product information"""
        selection = self.product_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a product")
            return
        
        item = self.product_tree.item(selection[0])
        product_id = item['values'][0]
        
        product = Product.get_product_by_id(product_id)
        if not product:
            messagebox.showerror("Error", "Product not found")
            return
        
        # Create details window
        details_window = tk.Toplevel(self.root)
        details_window.title("Product Details")
        details_window.geometry("500x400")
        details_window.configure(bg="white")
        
        tk.Label(details_window, text=product[1], font=("Arial", 18, "bold"),
                bg="white").pack(pady=20)
        
        details_frame = tk.Frame(details_window, bg="white")
        details_frame.pack(expand=True, padx=30)
        
        details = [
            ("Category:", product[2]),
            ("Description:", product[3]),
            ("Original Price:", f"${product[4]:.2f}"),
            ("Final Price:", f"${product[5]:.2f}"),
            ("Color:", product[6]),
            ("Available:", product[7]),
            ("Rating:", f"{product[8]}/5")
        ]
        
        for label, value in details:
            frame = tk.Frame(details_frame, bg="white")
            frame.pack(fill=tk.X, pady=5)
            
            tk.Label(frame, text=label, font=("Arial", 11, "bold"),
                    bg="white", width=15, anchor=tk.W).pack(side=tk.LEFT)
            tk.Label(frame, text=value, font=("Arial", 11),
                    bg="white", anchor=tk.W).pack(side=tk.LEFT)
    
    def show_cart(self):
        """Display shopping cart"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="Shopping Cart",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        if not self.cart:
            tk.Label(self.display_frame, text="Your cart is empty",
                    font=("Arial", 14), bg="white").pack(pady=50)
            return
        
        # Cart items
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        columns = ("ID", "Product", "Price", "Quantity", "Total")
        cart_tree = ttk.Treeview(tree_frame, columns=columns, show="headings")
        
        widths = [80, 300, 100, 100, 100]
        for col, width in zip(columns, widths):
            cart_tree.heading(col, text=col)
            cart_tree.column(col, width=width)
        
        cart_tree.pack(fill=tk.BOTH, expand=True)
        
        total_amount = 0
        for item in self.cart:
            item_total = item['price'] * item['quantity']
            total_amount += item_total
            cart_tree.insert("", tk.END, values=(
                item['serial_no'], item['name'], f"${item['price']:.2f}",
                item['quantity'], f"${item_total:.2f}"
            ))
        
        # Total
        tk.Label(self.display_frame, text=f"Total Amount: ${total_amount:.2f}",
                font=("Arial", 14, "bold"), bg="white").pack(pady=10)
        
        # Buttons
        button_frame = tk.Frame(self.display_frame, bg="white")
        button_frame.pack(pady=10)
        
        tk.Button(button_frame, text="Place Order", font=("Arial", 11, "bold"),
                 bg=COLOR_SUCCESS, fg="white", width=15, height=2,
                 command=self.place_order).pack(side=tk.LEFT, padx=5)
        
        tk.Button(button_frame, text="Clear Cart", font=("Arial", 11),
                 bg=COLOR_DANGER, fg="white", width=15,
                 command=self.clear_cart).pack(side=tk.LEFT, padx=5)
    
    def place_order(self):
        """Place order with cart items"""
        if not self.cart:
            messagebox.showwarning("Warning", "Cart is empty")
            return
        
        # Calculate total
        total_amount = sum(item['price'] * item['quantity'] for item in self.cart)
        
        # Ask for payment method
        payment_window = tk.Toplevel(self.root)
        payment_window.title("Payment Method")
        payment_window.geometry("300x200")
        payment_window.configure(bg="white")
        
        tk.Label(payment_window, text="Select Payment Method",
                font=("Arial", 14, "bold"), bg="white").pack(pady=20)
        
        payment_var = tk.StringVar(value="Cash")
        
        tk.Radiobutton(payment_window, text="Cash on Delivery",
                      variable=payment_var, value="Cash",
                      font=("Arial", 11), bg="white").pack(pady=5)
        tk.Radiobutton(payment_window, text="Credit Card",
                      variable=payment_var, value="Credit Card",
                      font=("Arial", 11), bg="white").pack(pady=5)
        
        def confirm_order():
            payment_type = payment_var.get()
            
            if Order.create_order(self.user_data['user_id'], total_amount,
                                 payment_type, self.cart):
                messagebox.showinfo("Success", "Order placed successfully!")
                self.cart = []
                self.update_cart_button()
                payment_window.destroy()
                self.show_orders()
            else:
                messagebox.showerror("Error", "Failed to place order")
        
        tk.Button(payment_window, text="Confirm Order", font=("Arial", 11, "bold"),
                 bg=COLOR_SUCCESS, fg="white", width=15,
                 command=confirm_order).pack(pady=20)
    
    def clear_cart(self):
        """Clear shopping cart"""
        if messagebox.askyesno("Confirm", "Clear all items from cart?"):
            self.cart = []
            self.update_cart_button()
            self.show_cart()
    
    def show_orders(self):
        """Display customer's order history"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="My Orders",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("Order No", "Date", "Amount", "Payment", "Status")
        order_tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                                 yscrollcommand=scrollbar.set)
        scrollbar.config(command=order_tree.yview)
        
        widths = [100, 180, 120, 120, 120]
        for col, width in zip(columns, widths):
            order_tree.heading(col, text=col)
            order_tree.column(col, width=width)
        
        order_tree.pack(fill=tk.BOTH, expand=True)
        
        orders = Order.get_customer_orders(self.user_data['user_id'])
        if orders:
            for order in orders:
                order_data = list(order)
                order_data[1] = str(order_data[1])[:19]
                order_tree.insert("", tk.END, values=order_data)
        
        # View order details button
        tk.Button(self.display_frame, text="View Order Items", font=("Arial", 11),
                 bg=COLOR_SECONDARY, fg="white", width=15,
                 command=lambda: self.view_order_items(order_tree)).pack(pady=10)
    
    def view_order_items(self, order_tree):
        """View items in selected order"""
        selection = order_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select an order")
            return
        
        item = order_tree.item(selection[0])
        order_no = item['values'][0]
        
        items = Order.get_order_items(order_no)
        if not items:
            messagebox.showinfo("Info", "No items found in this order")
            return
        
        # Create items window
        items_window = tk.Toplevel(self.root)
        items_window.title(f"Order #{order_no} Items")
        items_window.geometry("600x400")
        items_window.configure(bg="white")
        
        tk.Label(items_window, text=f"Order #{order_no} Items",
                font=("Arial", 16, "bold"), bg="white").pack(pady=20)
        
        tree_frame = tk.Frame(items_window, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        columns = ("Product", "Quantity", "Price Each", "Total")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings")
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=140)
        
        tree.pack(fill=tk.BOTH, expand=True)
        
        for item in items:
            tree.insert("", tk.END, values=(item[1], item[2],
                                           f"${item[3]:.2f}", f"${item[4]:.2f}"))