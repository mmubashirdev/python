"""
xflaire E-commerce Store - Main Application
A basic e-commerce system with Admin, Vendor, and Customer portals
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import tkinter as tk
from tkinter import messagebox
from database.db_connection import db
from ui.login_window import LoginWindow
from ui.admin_portal import AdminPortal
from ui.vendor_portal import VendorPortal
from ui.customer_portal import CustomerPortal
from utils.config import *


class XflaireApp:
    """Main application class"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title(f"{APP_NAME} - E-commerce Store")
        self.root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.root.configure(bg=COLOR_LIGHT)
        
        # Center window on screen
        self.center_window()
        
        # Current user data
        self.current_user = None
        
        # Connect to database
        if not db.connect():
            messagebox.showerror("Database Error",
                               "Failed to connect to database.\n"
                               "Please check your database configuration in utils/config.py")
            self.root.destroy()
            return
        
        # Show login window
        self.show_login()
    
    def center_window(self):
        """Center the window on screen"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def show_login(self):
        """Show login window"""
        LoginWindow(self.root, self.on_login_success)
    
    def on_login_success(self, user_data):
        """Handle successful login"""
        self.current_user = user_data
        
        # Route to appropriate portal based on role
        if user_data['role'] == 'admin':
            AdminPortal(self.root, user_data, self.logout)
        elif user_data['role'] == 'vendor':
            VendorPortal(self.root, user_data, self.logout)
        elif user_data['role'] == 'customer':
            CustomerPortal(self.root, user_data, self.logout)
    
    def logout(self):
        """Handle logout"""
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.current_user = None
            self.show_login()
    
    def run(self):
        """Start the application"""
        self.root.mainloop()
        
        # Cleanup
        db.disconnect()


def main():
    """Application entry point"""
    app = XflaireApp()
    app.run()


if __name__ == "__main__":
    main()