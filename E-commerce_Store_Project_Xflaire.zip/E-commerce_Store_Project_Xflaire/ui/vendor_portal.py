"""
Vendor/Seller Portal Interface
"""
import tkinter as tk
from tkinter import ttk, messagebox
from models.product import Product
from models.order import Order
from utils.config import *


class VendorPortal:
    """Vendor dashboard interface with CRUD operations"""
    
    def __init__(self, root, user_data, on_logout):
        self.root = root
        self.user_data = user_data
        self.on_logout = on_logout
        self.setup_ui()
    
    def setup_ui(self):
        """Setup vendor portal UI"""
        # Clear window
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Main container
        main_frame = tk.Frame(self.root, bg=COLOR_LIGHT)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Header
        header_frame = tk.Frame(main_frame, bg=COLOR_PRIMARY, height=60)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text=f"xflaire - Vendor Portal",
                font=("Arial", 20, "bold"), bg=COLOR_PRIMARY,
                fg="white").pack(side=tk.LEFT, padx=20)
        
        tk.Label(header_frame, text=f"{self.user_data['company_name']} - {self.user_data['first_name']}",
                font=("Arial", 12), bg=COLOR_PRIMARY,
                fg="white").pack(side=tk.RIGHT, padx=10)
        
        tk.Button(header_frame, text="Logout", font=("Arial", 10),
                 bg=COLOR_DANGER, fg="white", command=self.on_logout).pack(side=tk.RIGHT, padx=10)
        
        # Content area
        content_frame = tk.Frame(main_frame, bg=COLOR_LIGHT)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Menu buttons
        menu_frame = tk.Frame(content_frame, bg=COLOR_LIGHT)
        menu_frame.pack(fill=tk.X, pady=10)
        
        tk.Button(menu_frame, text="My Products", font=("Arial", 11),
                 bg=COLOR_SECONDARY, fg="white", width=15,
                 command=self.show_products).pack(side=tk.LEFT, padx=5)
        
        tk.Button(menu_frame, text="Add Product", font=("Arial", 11),
                 bg=COLOR_SUCCESS, fg="white", width=15,
                 command=self.show_add_product).pack(side=tk.LEFT, padx=5)
        
        tk.Button(menu_frame, text="My Orders", font=("Arial", 11),
                 bg=COLOR_WARNING, fg="white", width=15,
                 command=self.show_orders).pack(side=tk.LEFT, padx=5)
        
        # Display area
        self.display_frame = tk.Frame(content_frame, bg="white", relief=tk.RIDGE, bd=2)
        self.display_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Show products by default
        self.show_products()
    
    def clear_display(self):
        """Clear display area"""
        for widget in self.display_frame.winfo_children():
            widget.destroy()
    
    def show_products(self):
        """Display vendor's products with edit/delete options"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="My Products",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        # Create treeview
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("ID", "Name", "Category", "Price", "Final Price", 
                  "Color", "Available", "Rating")
        self.product_tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                                        yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.product_tree.yview)
        
        widths = [50, 150, 100, 80, 80, 80, 80, 60]
        for col, width in zip(columns, widths):
            self.product_tree.heading(col, text=col)
            self.product_tree.column(col, width=width)
        
        self.product_tree.pack(fill=tk.BOTH, expand=True)
        
        # Load products
        products = Product.get_products_by_vendor(self.user_data['user_id'])
        if products:
            for product in products:
                self.product_tree.insert("", tk.END, values=product)
        
        # Action buttons
        button_frame = tk.Frame(self.display_frame, bg="white")
        button_frame.pack(pady=10)
        
        tk.Button(button_frame, text="Edit Selected", font=("Arial", 11),
                 bg=COLOR_WARNING, fg="white", width=15,
                 command=self.edit_product).pack(side=tk.LEFT, padx=5)
        
        tk.Button(button_frame, text="Delete Selected", font=("Arial", 11),
                 bg=COLOR_DANGER, fg="white", width=15,
                 command=self.delete_product).pack(side=tk.LEFT, padx=5)
    
    def show_add_product(self):
        """Show add product form"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="Add New Product",
                font=("Arial", 16, "bold"), bg="white").pack(pady=20)
        
        # Form frame
        form_frame = tk.Frame(self.display_frame, bg="white")
        form_frame.pack(expand=True)
        
        # Form fields
        fields = [
            ("Product Name:", "name"),
            ("Category:", "category"),
            ("Description:", "description"),
            ("Price:", "price"),
            ("Final Price:", "final_price"),
            ("Color:", "color")
        ]
        
        self.add_entries = {}
        for label, key in fields:
            tk.Label(form_frame, text=label, font=("Arial", 11),
                    bg="white").grid(row=len(self.add_entries), column=0,
                                    sticky=tk.W, padx=20, pady=5)
            
            if key == "description":
                entry = tk.Text(form_frame, font=("Arial", 11), width=30, height=3)
            else:
                entry = tk.Entry(form_frame, font=("Arial", 11), width=30)
            
            entry.grid(row=len(self.add_entries), column=1, padx=20, pady=5)
            self.add_entries[key] = entry
        
        # Available dropdown
        tk.Label(form_frame, text="Available:", font=("Arial", 11),
                bg="white").grid(row=len(fields), column=0, sticky=tk.W, padx=20, pady=5)
        
        self.available_var = tk.StringVar(value="Yes")
        available_combo = ttk.Combobox(form_frame, textvariable=self.available_var,
                                      values=["Yes", "No"], state="readonly", width=28)
        available_combo.grid(row=len(fields), column=1, padx=20, pady=5)
        
        # Add button
        tk.Button(form_frame, text="Add Product", font=("Arial", 12, "bold"),
                 bg=COLOR_SUCCESS, fg="white", width=20, height=2,
                 command=self.add_product).grid(row=len(fields)+1, column=0,
                                               columnspan=2, pady=20)
    
    def add_product(self):
        """Add new product (CREATE operation)"""
        try:
            name = self.add_entries['name'].get().strip()
            category = self.add_entries['category'].get().strip()
            description = self.add_entries['description'].get("1.0", tk.END).strip()
            price = float(self.add_entries['price'].get().strip())
            final_price = float(self.add_entries['final_price'].get().strip())
            color = self.add_entries['color'].get().strip()
            available = self.available_var.get()
            
            if not all([name, category, price, final_price]):
                messagebox.showerror("Error", "Please fill all required fields")
                return
            
            if Product.create_product(name, category, description, price,
                                     final_price, color, available,
                                     self.user_data['user_id']):
                messagebox.showinfo("Success", "Product added successfully!")
                self.show_products()
            else:
                messagebox.showerror("Error", "Failed to add product")
        
        except ValueError:
            messagebox.showerror("Error", "Invalid price format")
    
    def edit_product(self):
        """Edit selected product (UPDATE operation)"""
        selection = self.product_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a product to edit")
            return
        
        item = self.product_tree.item(selection[0])
        product_data = item['values']
        product_id = product_data[0]
        
        # Get full product details
        product = Product.get_product_by_id(product_id)
        if not product:
            messagebox.showerror("Error", "Product not found")
            return
        
        # Create edit window
        edit_window = tk.Toplevel(self.root)
        edit_window.title("Edit Product")
        edit_window.geometry("500x600")
        edit_window.configure(bg="white")
        
        tk.Label(edit_window, text="Edit Product", font=("Arial", 16, "bold"),
                bg="white").pack(pady=20)
        
        # Form
        form_frame = tk.Frame(edit_window, bg="white")
        form_frame.pack(expand=True)
        
        fields = [
            ("Product Name:", product[1]),
            ("Category:", product[2]),
            ("Description:", product[3]),
            ("Price:", product[4]),
            ("Final Price:", product[5]),
            ("Color:", product[6])
        ]
        
        edit_entries = {}
        for i, (label, value) in enumerate(fields):
            tk.Label(form_frame, text=label, font=("Arial", 11),
                    bg="white").grid(row=i, column=0, sticky=tk.W, padx=20, pady=5)
            
            if label == "Description:":
                entry = tk.Text(form_frame, font=("Arial", 11), width=30, height=3)
                entry.insert("1.0", value if value else "")
            else:
                entry = tk.Entry(form_frame, font=("Arial", 11), width=30)
                entry.insert(0, value if value else "")
            
            entry.grid(row=i, column=1, padx=20, pady=5)
            edit_entries[label] = entry
        
        # Available
        tk.Label(form_frame, text="Available:", font=("Arial", 11),
                bg="white").grid(row=len(fields), column=0, sticky=tk.W, padx=20, pady=5)
        
        available_var = tk.StringVar(value=product[7])
        available_combo = ttk.Combobox(form_frame, textvariable=available_var,
                                      values=["Yes", "No"], state="readonly", width=28)
        available_combo.grid(row=len(fields), column=1, padx=20, pady=5)
        
        def save_changes():
            try:
                name = edit_entries["Product Name:"].get().strip()
                category = edit_entries["Category:"].get().strip()
                description = edit_entries["Description:"].get("1.0", tk.END).strip()
                price = float(edit_entries["Price:"].get().strip())
                final_price = float(edit_entries["Final Price:"].get().strip())
                color = edit_entries["Color:"].get().strip()
                available = available_var.get()
                
                if Product.update_product(product_id, name, category, description,
                                         price, final_price, color, available):
                    messagebox.showinfo("Success", "Product updated successfully!")
                    edit_window.destroy()
                    self.show_products()
                else:
                    messagebox.showerror("Error", "Failed to update product")
            except ValueError:
                messagebox.showerror("Error", "Invalid price format")
        
        tk.Button(form_frame, text="Save Changes", font=("Arial", 12, "bold"),
                 bg=COLOR_SUCCESS, fg="white", width=20, height=2,
                 command=save_changes).grid(row=len(fields)+1, column=0,
                                           columnspan=2, pady=20)
    
    def delete_product(self):
        """Delete selected product (DELETE operation)"""
        selection = self.product_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a product to delete")
            return
        
        item = self.product_tree.item(selection[0])
        product_id = item['values'][0]
        product_name = item['values'][1]
        
        if messagebox.askyesno("Confirm Delete",
                              f"Are you sure you want to delete '{product_name}'?"):
            if Product.delete_product(product_id):
                messagebox.showinfo("Success", "Product deleted successfully!")
                self.show_products()
            else:
                messagebox.showerror("Error", "Failed to delete product")
    
    def show_orders(self):
        """Display orders containing vendor's products"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="Orders with My Products",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("Order No", "Date", "Amount", "Payment", "Status", "Customer")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                           yscrollcommand=scrollbar.set)
        scrollbar.config(command=tree.yview)
        
        widths = [100, 180, 120, 120, 120, 150]
        for col, width in zip(columns, widths):
            tree.heading(col, text=col)
            tree.column(col, width=width)
        
        tree.pack(fill=tk.BOTH, expand=True)
        
        orders = Order.get_vendor_orders(self.user_data['user_id'])
        if orders:
            for order in orders:
                order_data = list(order)
                order_data[1] = str(order_data[1])[:19]
                tree.insert("", tk.END, values=order_data)