"""
Admin Portal Interface
"""
import tkinter as tk
from tkinter import ttk, messagebox
from models.user import User
from models.product import Product
from models.order import Order
from utils.config import *


class AdminPortal:
    """Admin dashboard interface"""
    
    def __init__(self, root, user_data, on_logout):
        self.root = root
        self.user_data = user_data
        self.on_logout = on_logout
        self.setup_ui()
    
    def setup_ui(self):
        """Setup admin portal UI"""
        # Clear window
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Main container
        main_frame = tk.Frame(self.root, bg=COLOR_LIGHT)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Header
        header_frame = tk.Frame(main_frame, bg=COLOR_PRIMARY, height=60)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        tk.Label(header_frame, text=f"xflaire - Admin Portal",
                font=("Arial", 20, "bold"), bg=COLOR_PRIMARY,
                fg="white").pack(side=tk.LEFT, padx=20)
        
        tk.Label(header_frame, text=f"Welcome, {self.user_data['first_name']}",
                font=("Arial", 12), bg=COLOR_PRIMARY,
                fg="white").pack(side=tk.RIGHT, padx=10)
        
        tk.Button(header_frame, text="Logout", font=("Arial", 10),
                 bg=COLOR_DANGER, fg="white", command=self.on_logout).pack(side=tk.RIGHT, padx=10)
        
        # Content area
        content_frame = tk.Frame(main_frame, bg=COLOR_LIGHT)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Menu buttons
        menu_frame = tk.Frame(content_frame, bg=COLOR_LIGHT)
        menu_frame.pack(fill=tk.X, pady=10)
        
        buttons = [
            ("View Customers", self.show_customers),
            ("View Vendors", self.show_vendors),
            ("View Delivery Persons", self.show_delivery_persons),
            ("View All Products", self.show_products),
            ("View All Orders", self.show_orders)
        ]
        
        for text, command in buttons:
            tk.Button(menu_frame, text=text, font=("Arial", 11),
                     bg=COLOR_SECONDARY, fg="white", width=18,
                     command=command).pack(side=tk.LEFT, padx=5)
        
        # Display area
        self.display_frame = tk.Frame(content_frame, bg="white", relief=tk.RIDGE, bd=2)
        self.display_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Show customers by default
        self.show_customers()
    
    def clear_display(self):
        """Clear display area"""
        for widget in self.display_frame.winfo_children():
            widget.destroy()
    
    def show_customers(self):
        """Display all customers"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="All Customers",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        # Create treeview
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Treeview
        columns = ("ID", "Username", "First Name", "Last Name", "Email")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                           yscrollcommand=scrollbar.set)
        scrollbar.config(command=tree.yview)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        
        tree.pack(fill=tk.BOTH, expand=True)
        
        # Load data
        customers = User.get_all_customers()
        if customers:
            for customer in customers:
                tree.insert("", tk.END, values=customer)
    
    def show_vendors(self):
        """Display all vendors"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="All Vendors",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("ID", "Username", "First Name", "Last Name", "Email", "Company")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                           yscrollcommand=scrollbar.set)
        scrollbar.config(command=tree.yview)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=130)
        
        tree.pack(fill=tk.BOTH, expand=True)
        
        vendors = User.get_all_vendors()
        if vendors:
            for vendor in vendors:
                tree.insert("", tk.END, values=vendor)
    
    def show_delivery_persons(self):
        """Display all delivery persons"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="All Delivery Persons",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("ID", "Username", "First Name", "Last Name", "Email")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                           yscrollcommand=scrollbar.set)
        scrollbar.config(command=tree.yview)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)
        
        tree.pack(fill=tk.BOTH, expand=True)
        
        delivery_persons = User.get_all_delivery_persons()
        if delivery_persons:
            for person in delivery_persons:
                tree.insert("", tk.END, values=person)
    
    def show_products(self):
        """Display all products"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="All Products",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("ID", "Name", "Category", "Price", "Final Price", 
                  "Color", "Available", "Vendor", "Company")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                           yscrollcommand=scrollbar.set)
        scrollbar.config(command=tree.yview)
        
        widths = [50, 120, 100, 80, 80, 80, 80, 100, 100]
        for col, width in zip(columns, widths):
            tree.heading(col, text=col)
            tree.column(col, width=width)
        
        tree.pack(fill=tk.BOTH, expand=True)
        
        products = Product.get_all_products()
        if products:
            for product in products:
                # Display only relevant columns
                display_data = (product[0], product[1], product[2], product[4],
                              product[5], product[6], product[7], product[9], product[10])
                tree.insert("", tk.END, values=display_data)
    
    def show_orders(self):
        """Display all orders"""
        self.clear_display()
        
        tk.Label(self.display_frame, text="All Orders",
                font=("Arial", 16, "bold"), bg="white").pack(pady=10)
        
        tree_frame = tk.Frame(self.display_frame, bg="white")
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("Order No", "Date", "Amount", "Payment", "Status", 
                  "Customer", "Name")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                           yscrollcommand=scrollbar.set)
        scrollbar.config(command=tree.yview)
        
        widths = [80, 150, 100, 100, 100, 120, 150]
        for col, width in zip(columns, widths):
            tree.heading(col, text=col)
            tree.column(col, width=width)
        
        tree.pack(fill=tk.BOTH, expand=True)
        
        orders = Order.get_all_orders()
        if orders:
            for order in orders:
                # Format date and combine customer name
                order_data = list(order)
                order_data[1] = str(order_data[1])[:19]  # Format datetime
                customer_full_name = f"{order_data[6]} {order_data[7]}"
                display_data = order_data[:6] + [customer_full_name]
                tree.insert("", tk.END, values=display_data)