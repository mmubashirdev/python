"""
Database connection and operations
"""
import pyodbc
from utils.config import DB_SERVER, DB_DATABASE


class DatabaseConnection:
    """Handle database operations"""
    
    def __init__(self):
        self.connection = None
        self.cursor = None
    
    def connect(self):
        """Connect to SQL Server database (Windows Authentication)"""
        try:
            connection_string = (
                f"Driver={{ODBC Driver 17 for SQL Server}};"
                f"Server={DB_SERVER};"
                f"Database={DB_DATABASE};"
                f"Trusted_Connection=yes;"
            )

            self.connection = pyodbc.connect(connection_string)
            self.cursor = self.connection.cursor()
            return True

        except Exception as e:
            print(f"Database connection error: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from database"""
        if self.connection:
            self.connection.close()
    
    def execute_query(self, query, params=None):
        """Execute SELECT query and return results"""
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Query execution error: {e}")
            return []
    
    def execute_update(self, query, params=None):
        """Execute INSERT/UPDATE/DELETE query"""
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            self.connection.commit()
            return True
        except Exception as e:
            print(f"Update execution error: {e}")
            self.connection.rollback()
            return False
    
    def execute_scalar(self, query, params=None):
        """Execute query and return single value"""
        try:
            if params:
                self.cursor.execute(query, params)
            else:
                self.cursor.execute(query)
            result = self.cursor.fetchone()
            return result[0] if result else None
        except Exception as e:
            print(f"Scalar execution error: {e}")
            return None


# Global database instance
db = DatabaseConnection()
