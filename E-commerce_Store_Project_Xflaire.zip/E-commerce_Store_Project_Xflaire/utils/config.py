"""
Configuration and constants for xflaire E-commerce application
"""

# Application Settings
APP_NAME = "xflaire"
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 700

# Colors
COLOR_PRIMARY = "#2C3E50"
COLOR_SECONDARY = "#3498DB"
COLOR_LIGHT = "#ECF0F1"
COLOR_DARK = "#34495E"
COLOR_DANGER = "#E74C3C"
COLOR_WARNING = "#F39C12"
COLOR_SUCCESS = "#27AE60"

# Database Settings
DB_SERVER = r"localhost\MSSQLSERVER01"
DB_DATABASE = "ecommerce"
DB_USER = ""          # Not needed for Windows authentication
DB_PASSWORD = ""      # Not needed for Windows authentication

