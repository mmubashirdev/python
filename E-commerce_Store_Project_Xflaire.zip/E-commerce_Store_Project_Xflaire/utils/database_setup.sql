-- xflaire E-commerce Database Setup Script
-- Execute this script in SQL Server Management Studio or Azure Data Studio

-- Create database
CREATE DATABASE ecommerce;
GO

USE ecommerce;
GO

-- Create tables
CREATE TABLE customer (
    customer_id INT IDENTITY(1,1) PRIMARY KEY,
    customer_name VARCHAR(20),
    password VARCHAR(20),
    first_name VARCHAR(20),
    last_name VARCHAR(20),
    email VARCHAR(50)
);

CREATE TABLE admins (
    admin_id INT IDENTITY(1,1) PRIMARY KEY,
    admin_name VARCHAR(20),
    password VARCHAR(20),
    first_name VARCHAR(20),
    last_name VARCHAR(20),
    email VARCHAR(50)
);

CREATE TABLE vendor (
    vendor_id INT IDENTITY(1,1) PRIMARY KEY,
    vendor_name VARCHAR(20),
    password VARCHAR(20),
    first_name VARCHAR(20),
    last_name VARCHAR(20),
    email VARCHAR(50),
    company_name VARCHAR(20),
    bank_acc_no VARCHAR(20),
    admin_id INT,
    FOREIGN KEY (admin_id) REFERENCES admins(admin_id)
);

CREATE TABLE delivery_person (
    delivery_id INT IDENTITY(1,1) PRIMARY KEY,
    username VARCHAR(20),
    password VARCHAR(20),
    first_name VARCHAR(20),
    last_name VARCHAR(20),
    email VARCHAR(50)
);

CREATE TABLE user_mobile_numbers (
    mobile_number VARCHAR(20),
    customer_id INT,
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
);

CREATE TABLE user_addresses (
    address VARCHAR(100),
    customer_id INT,
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id)
);

CREATE TABLE delivery (
    id INT IDENTITY(1,1) PRIMARY KEY,
    type VARCHAR(20),
    time_duration INT,
    fees DECIMAL(10,2),
    admin_id INT,
    FOREIGN KEY (admin_id) REFERENCES admins(admin_id)
);

CREATE TABLE credit_card (
    number VARCHAR(20) PRIMARY KEY,
    expiry_date DATE,
    cardno VARCHAR(4)
);

CREATE TABLE orders (
    order_no INT IDENTITY(1,1) PRIMARY KEY,
    order_date DATETIME,
    total_amount DECIMAL(10,2),
    payment_type VARCHAR(20),
    order_status VARCHAR(50),
    customer_id INT,
    delivery_id INT,
    creditcard_number VARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id),
    FOREIGN KEY (delivery_id) REFERENCES delivery(id),
    FOREIGN KEY (creditcard_number) REFERENCES credit_card(number)
);

CREATE TABLE product (
    serial_no INT IDENTITY(1,1) PRIMARY KEY,
    product_name VARCHAR(20),
    category VARCHAR(20),
    product_description TEXT,
    price DECIMAL(10,2),
    final_price DECIMAL(10,2),
    color VARCHAR(20),
    available VARCHAR(10),
    rate INT,
    vendor_id INT,
    FOREIGN KEY (vendor_id) REFERENCES vendor(vendor_id)
);

CREATE TABLE order_items (
    id INT IDENTITY(1,1) PRIMARY KEY,
    order_no INT,
    product_serial INT,
    quantity INT,
    price_each DECIMAL(10,2),
    FOREIGN KEY (order_no) REFERENCES orders(order_no),
    FOREIGN KEY (product_serial) REFERENCES product(serial_no)
);

CREATE TABLE customer_creditcard (
    customer_id INT,
    cc_number VARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id),
    FOREIGN KEY (cc_number) REFERENCES credit_card(number)
);

-- Insert sample data
INSERT INTO admins (admin_name, password, first_name, last_name, email) VALUES
('zain_admin','pass123','Muhammad','Zain','zain.admin@gmail.com'),
('musa_admin','pass123','Muhammad','Musa','musa.admin@gmail.com'),
('usama_admin','pass123','Muhammad','Usama','usama.admin@gmail.com'),
('mubashir_admin','pass123','Muhammad','Mubashir','mubashir.admin@gmail.com');

INSERT INTO customer (customer_name, password, first_name, last_name, email) VALUES
('zain_cust','cust123','Muhammad','Zain','zain.cust@gmail.com'),
('musa_cust','cust123','Muhammad','Musa','musa.cust@gmail.com'),
('usama_cust','cust123','Muhammad','Usama','usama.cust@gmail.com'),
('mubashir_cust','cust123','Muhammad','Mubashir','mubashir.cust@gmail.com');

INSERT INTO vendor (vendor_name, password, first_name, last_name, email, company_name, bank_acc_no, admin_id) VALUES
('zain_vendor','vend123','Muhammad','Zain','zain.vendor@gmail.com','ZainShop','1111222233334444',1),
('musa_vendor','vend123','Muhammad','Musa','musa.vendor@gmail.com','MusaMart','2222333344445555',2),
('usama_vendor','vend123','Muhammad','Usama','usama.vendor@gmail.com','UsamaMall','3333444455556666',3),
('Sameer_vendor','vend123','Rana','Sameer','sameer.vendor@gmail.com','SameerStore','4444555566667777',4);

INSERT INTO delivery_person (username, password, first_name, last_name, email) VALUES
('Mark','del123','Mark','Zuckerberg','zuckerberg.del@gmail.com'),
('Elon','del123','Elon','Musk','musk.del@gmail.com'),
('Tom','del123','Tom','Jerry','tom.del@gmail.com'),
('Bill','del123','Bill','Gates','gates.del@gmail.com');

PRINT 'Database setup completed successfully!';
PRINT 'You can now run the xflaire application.';
GO