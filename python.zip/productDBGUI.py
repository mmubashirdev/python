import pyodbc
con = pyodbc.connect(
  "Driver={ODBC Driver 17 for SQL Server};"
  "Server={localhost\\MSSQLSERVER01};"
  "trusted_connection=yes;",
  autocommit=True
)
cursor = con.cursor()
print("Connetion Established")

